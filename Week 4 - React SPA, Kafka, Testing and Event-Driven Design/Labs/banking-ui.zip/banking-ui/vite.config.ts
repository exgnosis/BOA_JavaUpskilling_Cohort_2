import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// All backend paths are forwarded to the BFF on port 8080 so the browser
// only ever talks to localhost:5173 in development (single origin).
// changeOrigin:false keeps the Host header as localhost:5173, which is what
// makes the OAuth redirect come back through this proxy (and keeps cookies).
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api':    { target: 'http://localhost:8080', changeOrigin: false },
      '/oauth2': { target: 'http://localhost:8080', changeOrigin: false },
      '/login':  { target: 'http://localhost:8080', changeOrigin: false },
      '/logout': { target: 'http://localhost:8080', changeOrigin: false },
    },
  },
});
